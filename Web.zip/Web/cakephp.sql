-- phpMyAdmin SQL Dump
-- version 4.5.4.1deb2ubuntu2
-- http://www.phpmyadmin.net
--
-- Servidor: localhost
-- Tiempo de generación: 19-06-2017 a las 22:34:05
-- Versión del servidor: 5.7.18-0ubuntu0.16.04.1
-- Versión de PHP: 7.0.18-0ubuntu0.16.04.1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `cakephp`
--
CREATE DATABASE IF NOT EXISTS `cakephp` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `cakephp`;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `analizadores`
--

CREATE TABLE `analizadores` (
  `id` int(11) NOT NULL,
  `nombre` varchar(1000) CHARACTER SET utf8 NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `analizadores`
--

INSERT INTO `analizadores` (`id`, `nombre`) VALUES
(1, 'NMAP'),
(2, 'NESSUS');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `analyses`
--

CREATE TABLE `analyses` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `probe_id` int(11) NOT NULL,
  `politica_id` int(11) NOT NULL,
  `analizador_id` int(11) NOT NULL,
  `descripcionpol` varchar(200) CHARACTER SET utf8 NOT NULL,
  `uuid_analysis` int(11) NOT NULL,
  `descripcion` varchar(1000) CHARACTER SET utf8 NOT NULL,
  `objetivos` varchar(2000) CHARACTER SET utf8 NOT NULL,
  `fechainicio` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `fechafin` timestamp NULL DEFAULT NULL,
  `estado` int(11) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `analyses`
--

INSERT INTO `analyses` (`id`, `user_id`, `probe_id`, `politica_id`, `analizador_id`, `descripcionpol`, `uuid_analysis`, `descripcion`, `objetivos`, `fechainicio`, `fechafin`, `estado`) VALUES
(3, 1, 9, 3, 0, 'analisis lento', 123123, 'descripcion formal del analisis 2 otra vez', '192.168.1.1', '2017-06-16 16:53:57', NULL, 1),
(4, 1, 9, 1, 1, 'general description', 5555, 'generic for te won', 'localhost', '2017-06-19 11:34:09', NULL, 0),
(5, 1, 9, 2, 1, 'analisis rapido', 5555, 'NUevo analisis de prueba', 'localhost', '2017-06-19 11:39:50', NULL, 0);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `hostinforms`
--

CREATE TABLE `hostinforms` (
  `id` int(11) NOT NULL,
  `host_id` int(11) NOT NULL,
  `os` varchar(100) CHARACTER SET utf8 NOT NULL,
  `devicetype` varchar(100) CHARACTER SET utf8 NOT NULL,
  `status` int(11) NOT NULL,
  `uptime` varchar(60) CHARACTER SET utf8 NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `hostinforms`
--

INSERT INTO `hostinforms` (`id`, `host_id`, `os`, `devicetype`, `status`, `uptime`) VALUES
(1, 1, 'linux', 'xerox', 1, '222222'),
(2, 2, 'windows', 'amd', 1, '333333');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `hosts`
--

CREATE TABLE `hosts` (
  `id` int(11) NOT NULL,
  `direccion` varchar(1000) CHARACTER SET utf8 NOT NULL,
  `descripcion` varchar(6000) CHARACTER SET utf8 NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `hosts`
--

INSERT INTO `hosts` (`id`, `direccion`, `descripcion`) VALUES
(1, '8.8.8.8', 'host uno'),
(2, '192.169.1.1', 'host dos');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `politicas`
--

CREATE TABLE `politicas` (
  `id` int(11) NOT NULL,
  `descripcion` varchar(1000) CHARACTER SET utf8 NOT NULL,
  `value` varchar(1000) CHARACTER SET utf8 NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `politicas`
--

INSERT INTO `politicas` (`id`, `descripcion`, `value`) VALUES
(1, 'analisis equipo actual', 'nmap -r'),
(2, 'analisis rapido', 'nmap -fast'),
(3, 'analisis lento', 'nmap -slow');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `portinforms`
--

CREATE TABLE `portinforms` (
  `id` int(11) NOT NULL,
  `hostinform_id` int(11) NOT NULL,
  `port` varchar(100) CHARACTER SET utf8 NOT NULL,
  `service` varchar(1000) CHARACTER SET utf8 NOT NULL,
  `version` varchar(100) CHARACTER SET utf8 NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `portinforms`
--

INSERT INTO `portinforms` (`id`, `hostinform_id`, `port`, `service`, `version`) VALUES
(1, 1, '8080', 'ssh', '1'),
(2, 2, '5555', 'http', '2');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `probes`
--

CREATE TABLE `probes` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `fechacreacion` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `nombre` varchar(40) CHARACTER SET utf8 NOT NULL DEFAULT 'default name',
  `descripcion` varchar(2000) CHARACTER SET utf8 NOT NULL DEFAULT 'default description',
  `ip` varchar(30) CHARACTER SET ucs2 NOT NULL DEFAULT '192.168.1.1',
  `puerto` varchar(30) CHARACTER SET utf8 NOT NULL DEFAULT '8080',
  `estado` int(11) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `probes`
--

INSERT INTO `probes` (`id`, `user_id`, `fechacreacion`, `nombre`, `descripcion`, `ip`, `puerto`, `estado`) VALUES
(9, 1, '2017-06-16 09:55:59', 'Sonda Prototipo', 'Descripcion del prototipo de la sonda 2', '192.168.1.1', '5555', 0);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `targets`
--

CREATE TABLE `targets` (
  `id` int(11) NOT NULL,
  `analyse_id` int(11) NOT NULL,
  `analysis_id` int(11) DEFAULT NULL,
  `tipo` varchar(1000) CHARACTER SET utf8 NOT NULL,
  `direccion` varchar(3000) CHARACTER SET utf8 NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `targets`
--

INSERT INTO `targets` (`id`, `analyse_id`, `analysis_id`, `tipo`, `direccion`) VALUES
(10, 4, NULL, 'ADDRESS', '192.169.1.1'),
(13, 4, NULL, 'ADDRESS', 'dsfsdffsdf'),
(15, 3, NULL, 'ADDRESS', '8.8.8.8,4.4.4.4'),
(16, 3, NULL, 'ADDRESS', '192.169.1.1');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `users`
--

CREATE TABLE `users` (
  `nombre` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL,
  `image` varchar(1000) NOT NULL,
  `nprobes` int(10) NOT NULL DEFAULT '0',
  `email` varchar(100) DEFAULT 'none@none.com',
  `id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Volcado de datos para la tabla `users`
--

INSERT INTO `users` (`nombre`, `password`, `image`, `nprobes`, `email`, `id`) VALUES
('admin', '$2a$10$Z2QHaXQ.gRZd.yBx1W0mOeRfQmNHh1euFMUtbCmn4qAnkNhrwEAie', '', 0, 'admin@admin.com', 1),
('b', '$2a$10$ArdfRS5NdplGtkk96eK9BeMPh3hA6gO925uxeM1W1kep3y20xE.iG', 'http://b.dryicons.com/images/icon_sets/colorful_stickers_part_3_icons_set/png/256x256/user.png', 0, 'b@b.com', 27),
('Juan', '$2a$10$5xcXiOx6Fq7clOlcqD216.d5igHxNJRS6fm5n1ptkGRqPoGfW.PZC', 'http://b.dryicons.com/images/icon_sets/colorful_stickers_part_3_icons_set/png/256x256/user.png', 0, 'juan@a.com', 28),
('a', '$2a$10$h0t0bPjs.CMtGgQB.IOkYeztkuf.i4UcUiuyfD5Mj/B3hxoF7qvU6', 'http://b.dryicons.com/images/icon_sets/colorful_stickers_part_3_icons_set/png/256x256/user.png', 0, 'a@a.com', 29),
('f', '$2a$10$DHSgZo1CZ84TB1kTJalB5uOhEfqfXCg/j.AEKDbBcKPQByGaVvoQS', 'http://b.dryicons.com/images/icon_sets/colorful_stickers_part_3_icons_set/png/256x256/user.png', 0, 'f@f.com', 30),
('pepe', '$2a$10$rq9xjEpUCMfYtpElLQRmjOJUDcum.iJsYJgCmh8gOPWb/H.iFIvwi', 'http://b.dryicons.com/images/icon_sets/colorful_stickers_part_3_icons_set/png/256x256/user.png', 0, 'pepe@pepe.com', 31);

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `analizadores`
--
ALTER TABLE `analizadores`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `analyses`
--
ALTER TABLE `analyses`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `hostinforms`
--
ALTER TABLE `hostinforms`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `hosts`
--
ALTER TABLE `hosts`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `politicas`
--
ALTER TABLE `politicas`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `portinforms`
--
ALTER TABLE `portinforms`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `probes`
--
ALTER TABLE `probes`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `targets`
--
ALTER TABLE `targets`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `analizadores`
--
ALTER TABLE `analizadores`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT de la tabla `analyses`
--
ALTER TABLE `analyses`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT de la tabla `hostinforms`
--
ALTER TABLE `hostinforms`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT de la tabla `hosts`
--
ALTER TABLE `hosts`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT de la tabla `politicas`
--
ALTER TABLE `politicas`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT de la tabla `portinforms`
--
ALTER TABLE `portinforms`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT de la tabla `probes`
--
ALTER TABLE `probes`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;
--
-- AUTO_INCREMENT de la tabla `targets`
--
ALTER TABLE `targets`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;
--
-- AUTO_INCREMENT de la tabla `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=32;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
