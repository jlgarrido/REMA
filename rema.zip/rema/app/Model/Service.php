<?php 
	class Service extends AppModel {

	public $name = 'Service';
	}
?>