<?php 
	class Target extends AppModel {

	public $name = 'Target';
	}
?>