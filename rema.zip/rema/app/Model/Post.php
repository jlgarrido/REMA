

<?php 
/*<?php
class Post extends AppModel {
	
	public $belongsTo = 'User';
	
    public $validate = array(
        'content' => array(
            'rule' => 'notEmpty'
        )
    );
	
	public function isOwnedBy($post, $user) {
	
		return $this->field('id', array('id' => $post, 'user_id' => $user)) !== false;
	}
}
?>*/
class Post extends AppModel {

	public $name = 'Post';

	public $belongsTo = 'User';
	


	
	  	
	public function isOwnedBy($post, $user) {
	
		return $this->field('id', array('id' => $post, 'user_id' => $user)) !== false;
	}
	 


	public $hasMany = array(
        'Comment'=>array(
            'className' => 'Comment',
            'foreignKey' => 'post_id',
            'dependent' => true,
            'order' => 'Comment.id ASC'
        )
    );

}
?>