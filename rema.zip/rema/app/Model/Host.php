<?php 
	class Host extends AppModel {

	public $name = 'Host';
	}
?>