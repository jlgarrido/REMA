

<?php 

class Analyse extends AppModel {

	public $name = 'Analyse';

	public $belongsTo = 'User';
	


	
	  	
	public function isOwnedBy($analyse, $user) {
	
		return $this->field('id', array('id' => $analyse, 'user_id' => $user)) !== false;
	}
	 


	/*public $hasMany = array(
        'Comment'=>array(
            'className' => 'Comment',
            'foreignKey' => 'post_id',
            'dependent' => true,
            'order' => 'Comment.id ASC'
        )
    );*/

}
?>