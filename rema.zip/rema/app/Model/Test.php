<?php 
App::uses('AppModel', 'Model');

class Test extends AppModel {
	public $name = 'Test';
}
	
?>