<?php 
	class Probe extends AppModel {

	public $name = 'Probe';
	}
?>