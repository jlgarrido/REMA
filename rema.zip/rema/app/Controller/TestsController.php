<?php 

App::uses('AppController', 'Controller');

class TestsController extends AppController{

	 public function add() {
        if ($this->request->is('test')) {
            $this->Test->create();

            if ($this->Test->save($this->request->data)) {
                $this->Flash->Set(__('Test correcto. Loguee para comenzar'));
                return $this->redirect(array('controller' => 'posts','action' => 'index'));
            }
            $this->Flash->set(
                __('The test could not be saved. Please, try again.')
            );
        }
    }

    public function index() {

      $this->loadModel('Test');
      $this->set('tests', $this->Test->find('all'));

	  //$this->set('tests', $this->Post->find('all'));
	}

}

 ?>