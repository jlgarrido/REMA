<?php
App::uses('AppController', 'Controller');

class AnalysesController extends AppController{

public $helpers = array('Html','Form', 'Time');
	

	public function index(){
		 $this->loadModel('Analyse');
        $this->set('analycers', $this->Analyse->find('all'));
        
        $this->Paginator->settings = $this->paginate;
        $data = $this->Paginator->paginate('Analyse');
     // ordena los analycers de mas viejo a más nuevo
  	    $this->set('analycers', $this->Analyse->find('all', array('order' => 'Analyse.id DESC')),$data);
	}


//crear analizadores
    public function add() {
	    if ($this->request->is('post')) {
	        $this->Analyse->create();
	        $this->loadModel('User');
            $this->set('users', $this->User->find('all')); 

            $this->request->data['Analyse']['user_id'] = $this->Auth->user('id');

	        if ($this->Analyse->save($this->request->data)) {
	        	foreach ($users as $user):
                        if($user['User']['id'] == $this->Auth->user('id')){
                          $this->User->updateAll(array('User.nanalisis' => 'User.nanalisis + 1'));
                        }
                 endforeach;
	            $this->Flash->Set(__('Analizador creado correctamente.'));
	            return $this->redirect(array('action' => 'index'));
	        }
	        $this->Flash->set(
	            __('El Analizador no se ha podido crear, por favor inténtalo de nuevo')
	        );
	    }
	}
//modificar analizadores

	public function edit($id=null)
	{
		if(!$id){
			throw new NotFoundException("El analizador no existe");
		}

		$analyzer = $this->Analyse->findById($id);
		if (!$analyzer) {
			throw new NotFoundException("El analizador no ha sido hayado");
		}

		if($this->request->is('post', 'put')){
			$this->Analyse->id = $id;
			if ($this->Analyse->save($this->request->data)) {
				$this->Flash->success('El analizador ha sido modificado');
				return $this->redirect(array('action' => 'index'));
			}

			$this->Flash->set('El registro NO SE HA MODIFICADO');
		}
		//muestra los datos a editar
		if (!$this->request->data) {
			$this->request->data = $analyzer;
		}
	}

//eliminar analizadores
public function delete($id=null)
	{
		$analyzer = $this->Analyse->findById($id);

		if (!$analyzer) {
			throw new NotFoundException("El analizador no ha sido hayado");
		}
		if($this->Analyse->delete($id)){
			$this->Flash->set('El registro NO SE HA MODIFICADO');
			return $this->redirect(array('action' => 'index'));
		}
	}
//consultar analizadores
public function view($id=null)
	{
		if (!$id) {
			throw new NotFoundException("Datos no validos");

		}
		/*Solo el registro especifico del analyzer con un determinado id*/
		$analyzer = $this->Analyse->findById($id);

		if (!$analyzer) {
			throw new NotFoundException("El usuario no existe");

		}

		$this->set('analyzer', $analyzer);
	}

	
}
?>
