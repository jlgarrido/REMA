<?php
App::uses('AppController', 'Controller');

class UsersController extends AppController{



public $helpers = array('Html','Form', 'Time');
	
public function beforeFilter() {
		parent::beforeFilter();
		$this->Auth->allow('add', 'logout');
		$this->set('current_user', $this->Auth->user());
	}

	public function login() {
		if ($this->request->is('post')) {

			if ($this->Auth->login()) {
	
				 return $this->redirect('/analyses/index');
			}
			$this->Flash->set(__('Invalid username or password, try again'));
		}
	}

	public function logout() {
		if($this->Auth->logout()){
			return $this->redirect('/');
		}
	}


	public function index()
	{
		/*Con esto listamos todos los ususarios de nuestro modelo*/
		$this->set('users', $this->User->find('all'));
	}

	public function view($id=null)
	{
		if (!$id) {
			throw new NotFoundException("Datos no validos");

		}
		/*Solo el registro especifico del user con un determinado Email*/
		$user = $this->User->findById($id);

		if (!$user) {
			throw new NotFoundException("El usuario no existe");

		}

		$this->set('user', $user);
	}
//añadir usuarios
	    public function add() {
        if ($this->request->is('post')) {
            $this->User->create();

            if ($this->User->save($this->request->data)) {
                $this->Flash->Set(__('Registro correcto. Loguee para comenzar'));
                return $this->redirect(array('action' => 'login'));
            }
            $this->Flash->set(
                __('The user could not be saved. Please, try again.')
            );
        }
    }


	public function edit($id=null)
	{
		if(!$id){
			throw new NotFoundException("El usuario no existe");
		}

		$user = $this->User->findById($id);
		if (!$user) {
			throw new NotFoundException("El usuario no ha sido hayado");
		}

		if($this->request->is('post', 'put')){
			$this->User->id = $id;
			if ($this->User->save($this->request->data)) {
				$this->Flash->success('El usuario ha sido modificado');
				return $this->redirect(array('action' => 'index'));
			}

			$this->Flash->set('El registro NO SE HA MODIFICADO NIGGA');
		}
		//muestra los datos a editar
		if (!$this->request->data) {
			$this->request->data = $user;
		}
	}

	public function delete($id=null)
	{
		$user = $this->User->findById($id);

		if (!$user) {
			throw new NotFoundException("El usuario no ha sido hayado");
		}
		if($this->User->delete($id)){
			$this->Flash->set('El registro NO SE HA MODIFICADO NIGGA');
			return $this->redirect(array('action' => 'index'));
		}
	}
}
?>
